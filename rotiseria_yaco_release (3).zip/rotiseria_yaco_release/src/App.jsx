import React, { useEffect, useState } from "react";

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthLoading, setIsAuthLoading] = useState(false); // Para el loading post-login
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    email: "",
    password: "",
    confirm: "",
  });
  const [isRegister, setIsRegister] = useState(false);
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showReceipt, setShowReceipt] = useState(false);
  const [order, setOrder] = useState(null);
  const [showProfile, setShowProfile] = useState(false); // Para el modal de perfil
  const [showMenu, setShowMenu] = useState(false); // Para el menú lateral
  const [orderStatus, setOrderStatus] = useState("Pendiente");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [toast, setToast] = useState({ show: false, message: "", icon: "" });
  const [alert, setAlert] = useState({ show: false, message: "", type: "info" });

  // Cargar datos previos
  useEffect(() => {
    const savedUser = localStorage.getItem("yaco_user");
    const savedCart = localStorage.getItem("yaco_cart");
    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedCart) setCart(JSON.parse(savedCart));
    setLoading(false);
  }, []);

  useEffect(() => {
    localStorage.setItem("yaco_cart", JSON.stringify(cart));
  }, [cart]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const showAlert = (message, type = "info", options = {}) => {
    const { onConfirm = null, autoClose = false } = options;
    setAlert({ show: true, message, type, onConfirm, autoClose });
    if (autoClose) {
      setTimeout(() => {
        setAlert(a => ({ ...a, show: false }));
      }, 2000);
    }
  };

  // Registro / Login
  async function handleAuth(e) {
    e.preventDefault();
    const users = JSON.parse(localStorage.getItem("yaco_users") || "[]");
    if (isRegister) {
      if (!form.nombre || !form.apellido || !form.email || !form.password || !form.confirm)
        return showAlert("Completá todos los campos.", "warning");
      if (!form.email.includes("@")) return showAlert("Ingresá un Gmail válido.", "warning");
      if (form.password !== form.confirm) return showAlert("Las contraseñas no coinciden.", "error");
      if (users.find((u) => u.email === form.email))
        return showAlert("Este correo ya está registrado.", "error");

      const newUser = { ...form };
      delete newUser.confirm;
      setIsAuthLoading(true);
      setTimeout(() => {
        users.push(newUser);
        localStorage.setItem("yaco_users", JSON.stringify(users));
        localStorage.setItem("yaco_user", JSON.stringify(newUser));
        setUser(newUser);
        setIsAuthLoading(false);
      }, 1500);
    } else {
      const existingUser = users.find(
        (u) => u.email === form.email && u.password === form.password
      );
      if (existingUser) {
        setIsAuthLoading(true);
        setTimeout(() => {
          localStorage.setItem("yaco_user", JSON.stringify(existingUser));
          setUser(existingUser);
          setIsAuthLoading(false);
        }, 1500);
      } else {
        showAlert("Usuario o contraseña incorrectos", "error");
      }
    }
  }

  const logout = () => {
    localStorage.removeItem("yaco_user");
    setUser(null);
  };

  // Productos
  const menuItems = [
    {
      name: "Milanesa de choclo con papas",
      desc: "Milanesa de choclo con papas de carne ",
      price: 20000,
      img: "/imagenes/milanesa choclo con papas.jpg",
      category: "Milanesas",
    },
    {
      name: "Empanada de Carne dulce",
      desc: "Empanada de Carne dulce",
      price: 1500,
      img: "/imagenes/emp-de-carnedulce.jpeg",
      category: "Empanadas",
    },
    
    {
      name: "Ensalada fresca",
      desc: "Mix de hojas verdes y vegetales",
      price: 3000,
      img: "https://images.unsplash.com/photo-1551218808-94e220e084d2?auto=format&fit=crop&w=800&q=80",
      category: "Guarnicion",
    },
    {
      name: "Milanesa de choclo con papas",
      desc: "Milanesa de choclo con papas de pollo",
      price: 19000,
      img: "/imagenes/milanesa choclo con papas.jpg",
      category: "Milanesas",
    },
    {
      name: "Empanada",
      desc: "Carne Salada",
      price: 800,
      img: "/imagenes/emp-de-carnesalada.jpeg",
      category: "Empanadas",
    },

    {
      name: "Ensalada fresca",
      desc: "Mix de hojas verdes y vegetales",
      price: 3000,
      img: "/imagenes/ensalada.webp",
      category: "Guarnicion",
    },
    {
      name: "Milanesa con papas",
      desc: "Milanesa de napolitana de carne",
      price: 20000,
      img: "/imagenes/milanesa-de-napolitana.webp",
      category: "Milanesas",
    },
    {
      name: "Empanada",
      desc: "Arabe",
      price: 1500,
      img: "/imagenes/emp-de-arabe.jpeg",
      category: "Empanadas",
    },
    
    {
      name: "Pizza ",
      desc: "Npolitana ",
      price: 14000,
      img: "/imagenes/pizza-de-napo.webp",
      category: "Pizzas",
    },
    {
      name: "Pizza",
      desc: "Pizza con muzzarella",
      price: 11000,
      img: "/imagenes/pizza-de-muzza.webp",
      category: "Pizzas",
    },
    {
      name: "Pizzanesa Napolitana",
      desc: "Pizzanesa de Napolitana para 4 personas",
      price: 2000,
      img: "/imagenes/pizzanesa.webp", // Imagen de ejemplo para pizzanesa
      category: "Pizzanesas",
    },
    {
      name: "Gaseosa Coca-Cola 1.5L",
      desc: "Refresco de cola",
      price: 5000,
      img: "/imagenes/coca-cola.webp",
      category: "Bebidas",
    },
    {
    },
    {
      name: "Agua saborizada 1,500ml",
      desc: "Agua mineral sin gas",
      price: 4000,
      img: "/imagenes/fresh.webp",
      category: "Bebidas",
    },
    {
      name: "Ravioles con Salsa Mixta",
      desc: "Ravioles caseros con salsa de tomate y crema",
      price: 8000,
      img: "/imagenes/ravioles-con-salsa.webp",
      category: "Pastas",
    },
    {
      name: "Familiar",
      desc: "Fmiliar de carne x3",
      price: 30000,
      img: "/imagenes/familiar.jpeg",
      category: "Sandwich",
    },
    {
      name: "Papas Fritas Grandes",
      desc: "Porción grande de papas fritas",
      price: 11000,
      img: "/imagenes/papas fritas.webp", // Imagen de ejemplo para guarnición
      category: "Guarnicion",
    },
    {
      name: "Empanada",
      desc: " jamón y queso ",
      price: 1500,
      img: "/imagenes/emp-de-jamonyqueso.jpeg",
      category: "Empanadas",
    },
    
  ];

  // Formatear precios
  const formatPrice = (price) => new Intl.NumberFormat("es-AR").format(price);
   // Notificación Toast
  // Carrito
  const addToCart = (item) => {
    setCart(currentCart => {
      const existingItem = currentCart.find(cartItem => cartItem.name === item.name);
      if (existingItem) {
        return currentCart.map(cartItem =>
          cartItem.name === item.name
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      }
      return [...currentCart, { ...item, quantity: 1 }];
    });
    showAlert(`${item.name} se agregó exitosamente al carrito`, "success", { autoClose: true });
  };
  const updateQuantity = (itemName, amount) => {
    setCart(currentCart =>
      currentCart
        .map(item => (item.name === itemName ? { ...item, quantity: item.quantity + amount } : item))
        .filter(item => item.quantity > 0)
    );
  };
  
  const clearCart = () => setCart([]);

  const total = cart.reduce((t, i) => t + i.price * i.quantity, 0);

  // Confirmar pedido
  const confirmOrder = (datos) => {
    const newOrder = {
      id: Date.now(),
      cliente: {
        nombre: datos.nombre,
        direccion: datos.direccion,
        horario: datos.horario,
        pago: datos.pago,
      },
      productos: cart,
      total,
      estado: "Pendiente",
    };

    setOrder(newOrder);
    setShowForm(false);
    setShowReceipt(true);

    // Guardar en localStorage
    const saved = JSON.parse(localStorage.getItem("yaco_orders") || "[]");
    saved.push(newOrder);
    localStorage.setItem("yaco_orders", JSON.stringify(saved));

    // Simular estados
    setOrderStatus("Pendiente");
    setTimeout(() => setOrderStatus("Confirmado"), 3000);
    setTimeout(() => setOrderStatus("En preparación"), 6000);
    setTimeout(() => setOrderStatus("Listo"), 9000);
    setTimeout(() => setOrderStatus("Enviado"), 12000);
     setTimeout(() => {
      setOrderStatus("Entregado");
      showAlert("¡Pedido entregado con éxito!", "success");
      clearCart();
      setShowReceipt(false);
    }, 12000);
  };

  // Pantalla carga
  if (loading)
    return (
      <div style={styles.loading}>
        <img src="/imagenes/pajaro_loco.png" alt="Logo" style={styles.loadingLogo} />
        <p>Cargando...</p>
      </div>
    );

  // Loading después de iniciar sesión/registrarse
  if (isAuthLoading)
    return (
      <div style={styles.loading}>
        <img src="/imagenes/pajaro_loco.png" alt="Logo" style={styles.loadingLogo} />
        <p>Iniciando sesión...</p>
      </div>
    );


  // Login / registro
  if (!user)
    return (
      <div style={styles.authContainer}>
        <img src="/imagenes/pajaro_loco.png" alt="Rotisería Yaco" style={styles.authLogo} />
        <h1>Rotisería Yaco</h1>
        <form onSubmit={handleAuth} style={styles.form}>
          {isRegister && (
            <>
              <input
                name="nombre"
                placeholder="Nombre"
                value={form.nombre}
                onChange={handleChange}
                style={styles.input}
              />
              <input
                name="apellido"
                placeholder="Apellido"
                value={form.apellido}
                onChange={handleChange}
                style={styles.input}
              />
            </>
          )}
          <input
            name="email"
            type="email"
            placeholder="Gmail"
            value={form.email}
            onChange={handleChange}
            style={styles.input}
          />
          <input
            name="password"
            type="password"
            placeholder="Contraseña"
            value={form.password}
            onChange={handleChange}
            style={styles.input}
          />
          {isRegister && (
            <input
              name="confirm"
              type="password"
              placeholder="Confirmar contraseña"
              value={form.confirm}
              onChange={handleChange}
              style={styles.input}
            />
          )}
          <button type="submit" style={styles.button}>
            {isRegister ? "Registrarme" : "Ingresar"}
          </button>
          <button
            type="button"
            onClick={() => setIsRegister(!isRegister)}
            style={{ ...styles.button, background: "transparent", border: "2px solid #fff" }}
          >
            {isRegister ? "Ya tengo cuenta" : "Crear cuenta nueva"}
          </button>
        </form>
      </div>
    );

  const categories = ["Todos", ...new Set(menuItems.map(item => item.category))];
  const filteredMenuItems = selectedCategory
    ? menuItems.filter(item => item.category === selectedCategory)
    : menuItems;

  // Página principal
  return (
    <div>
      {/* Estilos para animaciones dinámicas */}
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .promo-card-animation {
            animation: fadeIn 0.6s ease-out forwards;
          }
          @keyframes scroll-horizontal {
            from { transform: translateX(0); }
            to { transform: translateX(-50%); }
          }
           @keyframes toast-in {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
          .toast-animation {
            animation: toast-in 0.5s ease;
          }
        `}
      </style>

      <header style={{...styles.header, justifyContent: "space-between"}}>
        <button onClick={() => {
          console.log('Menu button clicked');
          setShowMenu(true);
        }} style={styles.menuBtn}>
          <img src="/imagenes/menu.png" alt="Menú" style={{ width: '24px', height: '24px' }} />
        </button>
        <div style={{ textAlign: 'center' }}>
          <img src="/imagenes/pajaro_loco.png" style={{ width: 40, verticalAlign: 'middle', marginRight: 8 }} alt="Logo" />
          <span style={{ fontWeight: "bold" }}>👋 Hola, {user.nombre}{user.apellido} </span>
        </div>
        <div style={{display: 'flex', alignItems: 'center'}}>
          <button onClick={() => setShowProfile(true)} style={styles.profileBtn} title="Mi Perfil">
            <img
              src="/imagenes/perfil-de-usuario.png"
              alt="Perfil"
              style={{ width: "28px", height: "28px" }}
            />
          </button>
          <button onClick={logout} style={styles.logoutBtn} title="Cerrar Sesión">
            <img 
              src="/imagenes/cerrar-sesion.png" 
              alt="Cerrar Sesión" 
              style={{ width: "24px", height: "24px" }}/>
          </button>
        </div>
      </header>

      <section style={styles.hero}>
    <h1>Comida casera las llevamos hasta tu casa</h1>
        <p style={{ fontSize: "1.1rem", marginTop: 10 }}>Pedidos en línea • Entrega rápida • Comida fresca</p>
      </section>

      {/* --- SECCIÓN DE BENEFICIOS --- */}
      <section style={styles.benefits}>
    <h2><img src="/imagenes/estrella.png" alt="Icono estrella" style={{ width: "24px", height: "24px", verticalAlign: "middle", marginRight: "8px" }} /> ¿Por qué elegir Rotisería Yaco?</h2>
        <div style={styles.benefitsGrid}>
          <div style={styles.benefitCard}>
            <img src="/imagenes/entrega-a-domicilio.png" alt="Entrega Rápida" style={styles.benefitIcon} />
            <h3>Entrega Rápida</h3>
            <p>Recibí tu pedido en 30 minutos</p>
          </div>
          <div style={styles.benefitCard}>
            <img src="/imagenes/cocinero.png" alt="Cocineros Expertos" style={styles.benefitIcon} />
            <h3>Cocineros Expertos</h3>
            <p>Recetas tradicionales y deliciosas</p>
          </div>
          <div style={styles.benefitCard}>
            <img src="/imagenes/saludable.png" alt="Ingredientes Frescos" style={styles.benefitIcon} />
            <h3>Ingredientes Frescos</h3>
            <p>Productos de primera calidad</p>
          </div>
          <div style={styles.benefitCard}>
            <img src="/imagenes/mejor-precio.png" alt="Mejores Precios" style={styles.benefitIcon} />
            <h3>Mejores Precios</h3>
            <p>Promociones todos los días</p>
          </div>
        </div>
      </section>

      <section style={styles.menu}>
        <h2 style={{ color: "#1e90ff" }}>Menú</h2>
        <div style={styles.filterContainer}>
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category === 'Todos' ? null : category)}
              style={selectedCategory === category || (selectedCategory === null && category === 'Todos') ? styles.filterButtonActive : styles.filterButton}
            >
              {category}
            </button>
          ))}
        </div>
        <div style={styles.grid}>
          {filteredMenuItems.map((p, i) => (
            <div key={i} style={styles.card}>
              <img src={p.img} alt={p.name} style={styles.image} />
              <h3>{p.name}</h3>
              <p>{p.desc}</p>
              <div style={styles.cardFooter}>
                <strong>${formatPrice(p.price)}</strong>
                <button onClick={() => addToCart(p)} style={styles.addBtn}>
                  ➕ Agregar
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- GALERÍA DE PROMOS --- */}
      <section style={styles.promos}>
        <h2 style={{ color: "#ff4d4d" }}>Promos </h2>
        <div style={styles.gallery} onMouseEnter={(e) => e.currentTarget.style.animationPlayState = 'paused'} onMouseLeave={(e) => e.currentTarget.style.animationPlayState = 'running'}>
          {[
            { 
              img: "/imagenes/promo 1.jpeg", 
              title: "1 pizza de muzzarella + 1 tostado con papa ",
              name: "Promo 1",
              price: 20500,
              desc: ""
            },
           
            { 
              img: "/imagenes/promo 3.jpeg", 
              title: "1 pizza especial + 1 pizza de muzzarella",
              name: "promo 3",
              price: 23500,
              desc: ""
            },
             { 
              img: "/imagenes/promo2.jpeg", 
              title: "1 pizza especial +1 Tostado con papas",
              name: "promo 2",
              price: 22500,
              desc: ""
            },
            { 
              img: "/imagenes/promo4.jpeg", 
              title: "1 pizza especial + 6 empanadas",
              name: "promo4",
              price: 21500,
              desc: ""
            },
             { 
              img: "/imagenes/promo5.jpeg", 
              title: " 1 pizza de muzza + 6 empanada ",
              name: "Promo 5",
              price: 25000,
              desc: ""
            },
          ].flatMap(p => [p, p]).map((p, i) => ( // Duplicamos para el carrusel
            <div key={i} style={{...styles.promoCard, animationDelay: `${i * 100}ms`}} className="promo-card-animation">
              <img src={p.img} alt={p.title} style={styles.promoImg} />
              <div style={styles.promoCardContent}>
                <p style={{ margin: 0, fontWeight: 'bold' }}>{p.title}</p>
                <div style={styles.cardFooter}>
                  <strong>${formatPrice(p.price)}</strong>
                  <button onClick={() => addToCart(p)} style={styles.addBtn}>
                    ➕ Agregar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- SECCIÓN DE CONTACTO --- */}
      <section style={styles.contacto}>
        <h2>¿Preguntas? Contactanos <img src="/imagenes/telefono.png" alt="Contacto" style={{ width: "24px", height: "24px", verticalAlign: "middle" }} /></h2>
        <div style={styles.contactoInfo}>
          <p><img src="/imagenes/whatsapp.png" alt="WhatsApp" style={styles.contactIcon} /><strong>WhatsApp:</strong> +54 9 3471 56 8233</p>
          <p><img src="/imagenes/horario-de-apertura.png" alt="Horarios" style={styles.contactIcon} /><strong>Horarios:</strong> Miercoles-Domimgo 19:00 - 23:00</p>
          <p><img src="/imagenes/mapas-de-google.png" alt="Dirección" style={styles.contactIcon} /><strong>Dirección:</strong> Laprida 1494,Cañada de Gomez,Santa fe</p>
          <p><img src="/imagenes/facebook.png" alt="Facebook" style={styles.contactIcon} /><strong>Facebook</strong> Rotiseria Yaco</p>
          <p><img src="/imagenes/instagram.png" alt="Instagram" style={styles.contactIcon} /><strong>instagram</strong> @rotiseriayaco</p>
        </div>
      </section>

      <div style={styles.cartButton} onClick={() => setShowCart(!showCart)}>
        <img
          src="/imagenes/compras.png"
          alt="Carrito"
          style={{ width: "28px", height: "28px" }}
        />
        {cart.length > 0 && (
          <span style={styles.cartCount}>{cart.length}</span>
        )}
      </div>

      {showCart && (
        <div style={styles.cartPanel}>
          <h3>
            <img
              src="/imagenes/realizar-pedido.png"
              alt="Carrito"
              style={{ width: '24px', height: '24px', verticalAlign: 'middle', marginRight: '8px' }}
            />
            Tu pedido
          </h3>
          {cart.length === 0 ? (
            <p>Tu carrito está vacío</p>
          ) : (
            <>
              <ul style={{ listStyle: "none", padding: 0 }}>
                {cart.map((item) => (
                  <li key={item.name} style={styles.cartItem}>
                    <span style={{flex: 1, marginRight: '10px'}}>{item.name}</span>
                    <div style={styles.quantityControl}>
                      <button onClick={() => updateQuantity(item.name, -1)} style={styles.quantityBtn}>-</button>
                      <span style={{padding: '0 8px', fontWeight: 'bold'}}>{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.name, 1)} style={styles.quantityBtn}>+</button>
                    </div>
                    <strong style={{width: '80px', textAlign: 'right'}}>${formatPrice(item.price * item.quantity)}</strong>
                  </li>
                ))}
              </ul>
              <p><b>Total:</b> ${formatPrice(total)}</p>
              <button onClick={() => setShowForm(true)} style={styles.confirmBtn}>
                Confirmar pedido
              </button>
            </>
          )}
        </div>
      )}

      {showForm && (
        <OrderForm
          user={user}
          onClose={() => setShowForm(false)}
          onConfirm={confirmOrder}
        />
      )}

      {showProfile && (
        <ProfileModal user={user} setUser={setUser} onClose={() => setShowProfile(false)} />
      )}

      {showMenu && (
        <SideMenu
          user={user}
          onClose={() => setShowMenu(false)}
          onLogout={logout}
          showAlert={showAlert}
        />
      )}

      {showReceipt && order && (
        <ReceiptModal order={order} status={orderStatus} onClose={() => setShowReceipt(false)} />
      )}

      <AlertModal
        {...alert}
        message={alert.message}
        type={alert.type}
        onConfirm={alert.onConfirm}
        onClose={() => setAlert({ ...alert, show: false })}
      />
      <footer style={styles.footer}>
        <span>© 2025 Rotisería Yaco — Todos los derechos reservados.</span>
      </footer>
    </div>
  );
}

// 👤 Modal de Perfil
function ProfileModal({ user, setUser, onClose, showAlert }) {
  const [isEditing, setIsEditing] = useState(false);
  const [profileForm, setProfileForm] = useState({
    nombre: user.nombre || "",
    apellido: user.apellido || "",
    direccion: user.direccion || "",
  });

  const handleProfileChange = (e) => {
    setProfileForm({ ...profileForm, [e.target.name]: e.target.value });
  };

  const handleProfileSave = () => {
    const updatedUser = { ...user, ...profileForm };
    setUser(updatedUser);
    localStorage.setItem("yaco_user", JSON.stringify(updatedUser));
    setIsEditing(false);
    showAlert("Perfil actualizado con éxito.", "success", { autoClose: true });
  };

  return (
    <div style={styles.modalOverlay} onClick={onClose}>
      <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
        <h2>Mi Perfil</h2>
        {isEditing ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <input
              name="nombre"
              placeholder="Nombre"
              value={profileForm.nombre}
              onChange={handleProfileChange}
              style={styles.input}
            />
            <input
              name="apellido"
              placeholder="Apellido"
              value={profileForm.apellido}
              onChange={handleProfileChange}
              style={styles.input}
            />
            <input
              name="direccion"
              placeholder="Dirección"
              value={profileForm.direccion}
              onChange={handleProfileChange}
              style={styles.input}
            />
            <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
              <button onClick={handleProfileSave} style={styles.button}>Guardar</button>
              <button onClick={() => setIsEditing(false)} style={styles.clearBtn}>Cancelar</button>
            </div>
          </div>
        ) : (
          <div style={{ textAlign: "left", lineHeight: 1.8 }}>
            <p><strong>Nombre:</strong> {user.nombre}</p>
            <p><strong>Apellido:</strong> {user.apellido}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Dirección:</strong> {user.direccion || "No especificada"}</p>
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              <button onClick={() => setIsEditing(true)} style={styles.button}>Editar</button>
              <button onClick={onClose} style={styles.clearBtn}>Cerrar</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// 🍔 Menú Lateral
function SideMenu({ user, onClose, onLogout, showAlert }) {
  const [userOrders, setUserOrders] = useState([]);

  useEffect(() => {
    const orders = JSON.parse(localStorage.getItem("yaco_orders") || "[]");
    const filteredOrders = orders.filter(o => o.cliente.nombre === `${user.nombre} ${user.apellido}`);
    setUserOrders(filteredOrders);
  }, [user]);

  const deleteOrder = (orderId) => {
    showAlert(
      "¿Estás seguro de que querés eliminar este pedido?",
      "warning", {
      onConfirm: () => {
        const allOrders = JSON.parse(localStorage.getItem("yaco_orders") || "[]");
        const updatedOrders = allOrders.filter(o => o.id !== orderId);
        localStorage.setItem("yaco_orders", JSON.stringify(updatedOrders));
        setUserOrders(updatedOrders.filter(o => o.cliente.nombre === `${user.nombre} ${user.apellido}`));
      showAlert("Pedido eliminado", "success", { autoClose: true });
      }
    });
  };

  return (
    <div style={styles.sideMenuOverlay} onClick={onClose}>
      <div style={styles.sideMenu} onClick={(e) => e.stopPropagation()}>
        <h3>Menú</h3>
        <div style={styles.menuSection}>
          <h4 style={{ marginBottom: 15 }}>Mis Pedidos</h4>
          {userOrders.length > 0 ? (
            <ul style={{ listStyle: "none", padding: 0, fontSize: "0.9rem", overflowY: 'auto', maxHeight: 'calc(100vh - 150px)' }}>
              {userOrders.map(order => (
                <li key={order.id} style={styles.orderCard}>
                  <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #eee', paddingBottom: 8, marginBottom: 8}}>
                    <strong style={{color: '#1e90ff'}}>ID: {order.id}</strong>
                    <button onClick={() => deleteOrder(order.id)} style={styles.deleteOrderBtn}>
                      <img src="/imagenes/cruzar.png" alt="Eliminar" style={{width: 16, height: 16}} />
                    </button>
                  </div>
                  <p><strong>Cliente:</strong> {order.cliente.nombre}</p>
                  <p><strong>Dirección:</strong> {order.cliente.direccion}</p>
                  {order.cliente.horario && <p><strong>Horario:</strong> {order.cliente.horario}</p>}
                  <p><strong>Estado:</strong> {order.estado}</p>
                  <div style={{margin: '8px 0'}}>
                    <strong>Detalle:</strong>
                    <ul style={{paddingLeft: 20, margin: '5px 0 0'}}>
                      {order.productos.map((p, i) => <li key={i}>{p.name} x{p.quantity}</li>)}
                    </ul>
                  </div>
                  <p style={{textAlign: 'right', fontWeight: 'bold', marginTop: 8}}>Total: ${formatPrice(order.total)}</p>
                </li>
              ))}
             </ul>
          ) : (
            <p style={{ fontSize: "0.9rem", color: "#666" }}>No tenés pedidos.</p>
          )}
        </div>
        <button onClick={onLogout} style={styles.logoutBtnFull}>
          <img
            src="/imagenes/cerrar-sesion.png"
            alt="Cerrar Sesión"
            style={{ width: "20px", height: "20px", marginRight: 8 }}
          />
          Cerrar Sesión
        </button>
      </div>
    </div>
  );
}

const formatPrice = (price) => new Intl.NumberFormat("es-AR").format(price);

// 🧾 Formulario de pedido
function OrderForm({ user, onClose, onConfirm, showAlert }) {
  const [datos, setDatos] = useState({
    nombre: user.nombre + " " + user.apellido,
    direccion: "",
    horario: "",
    pago: "Efectivo",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!datos.direccion.trim()) {
      showAlert("Por favor ingresá una dirección.", "warning");
      return;
    }
    onConfirm(datos);
  };

  return (
    <div style={styles.modalOverlay}>
      <div style={styles.modal}>
        <h2>Completar datos de entrega</h2>
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <input
            name="nombre"
            placeholder="Nombre completo"
            value={datos.nombre}
            onChange={(e) => setDatos({ ...datos, nombre: e.target.value })}
            style={styles.input}
          />
          <input
            name="direccion"
            placeholder="Dirección"
            value={datos.direccion}
            onChange={(e) => setDatos({ ...datos, direccion: e.target.value })}
            style={styles.input}
            required
          />
          <input
            name="horario"
            placeholder="Horario de entrega (opcional)"
            value={datos.horario}
            onChange={(e) => setDatos({ ...datos, horario: e.target.value })}
            style={styles.input}
          />
          <select
            name="pago"
            value={datos.pago}
            onChange={(e) => setDatos({ ...datos, pago: e.target.value })}
            style={styles.input}
          >
            <option value="Efectivo">Efectivo</option>
            <option value="Transferencia">Transferencia</option>
          </select>
          {datos.pago === "Transferencia" && (
            <div style={{ padding: 10, background: "#f0f8ff", borderRadius: 8, marginTop: 5, textAlign: 'left', fontSize: '0.9rem' }}>
              <p style={{ margin: 0, fontWeight: "bold", color: "#1e90ff" }}>Datos para la transferencia:</p>
              <p style={{ margin: "5px 0 0" }}><strong>Alias/CVU:</strong> rotiseria.yaco.mp</p>
              <p style={{ margin: "5px 0 0" }}><strong>Titular:</strong> Rotiseria Yaco</p>
              <p style={{ margin: "5px 0 0" }}><strong>Banco:</strong> Mercado Pago</p>
            </div>
          )}
          <div style={{ display: "flex", gap: 10 }}>
            <button type="submit" style={styles.button}>
              Confirmar
            </button>
            <button type="button" onClick={onClose} style={styles.clearBtn}>
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// 🧾 Modal comprobante
function ReceiptModal({ order, status, onClose }) {
  return (
    <div style={styles.modalOverlay}>
      <div style={{...styles.modal, textAlign: 'left'}}>
        <h2>Comprobante de pedido</h2>
        <p><strong>ID de comprobante:</strong> {order.id}</p>
        <p><strong>Nombre y Apellido:</strong> {order.cliente.nombre}</p>
        <p><strong>Dirección:</strong> {order.cliente.direccion}</p>
        {order.cliente.horario && <p><strong>Horario de entrega:</strong> {order.cliente.horario}</p>}
        <p><strong>Método de Pago:</strong> {order.cliente.pago}</p>
        
        <div style={{borderTop: '1px solid #eee', borderBottom: '1px solid #eee', padding: '10px 0', margin: '10px 0'}}>
          <h4 style={{marginTop: 0}}>Detalle del pedido:</h4>
          <ul style={{ paddingLeft: 20, margin: 0 }}>
          {order.productos.map((p, i) => (
            <li key={i}>{p.name} x{p.quantity} - ${formatPrice(p.price * p.quantity)}</li>
          ))}
        </ul>
        </div>

        <p><strong>Total:</strong> ${formatPrice(order.total)}</p>
        <p><strong>Estado del pedido:</strong> <span style={{ color: "#1e90ff", fontWeight: "bold" }}>{status}</span></p>
        
        <button onClick={onClose} style={{...styles.button, width: '100%', marginTop: 15}}>Cerrar</button>
      </div>
    </div>
  );
}

// ✨ Modal de Alerta Dinámica
function AlertModal({ show, message, type, onConfirm, onClose, autoClose }) {
  if (!show) return null; 

  const config = {
    info: { bg: '#e7f3ff', color: '#1e90ff', icon: 'ℹ️' },
    warning: { bg: '#fffbe6', color: '#faad14', icon: '⚠️' },
    error: { bg: '#fff1f0', color: '#ff4d4d', icon: '❌' },
    success: { bg: '#f6ffed', color: '#52c41a', icon: '✅' },
  };

  const current = config[type] || config.info;

  const handleConfirm = () => {
    if (onConfirm) onConfirm();
    onClose();
  };

  return (
    <div style={styles.modalOverlay}>
      <div style={{...styles.modal, borderTop: `5px solid ${current.color}`, background: current.bg }}>
        <span style={{ fontSize: '2.5rem', display: 'block', marginBottom: 15 }}>{current.icon}</span>
        <p style={{ color: '#333', fontWeight: 500, margin: 0, lineHeight: 1.5 }}>{message}</p>
        {!autoClose && <div style={{ display: 'flex', gap: 10, marginTop: 20, justifyContent: 'center' }}>
          {onConfirm ? (
            <>
              <button onClick={handleConfirm} style={{...styles.button, background: current.color}}>
                Confirmar
              </button>
              <button onClick={onClose} style={{...styles.clearBtn, background: '#ccc', color: '#000'}}>
                Cancelar
              </button>
            </>
          ) : (
            <button onClick={onClose} style={{...styles.button, background: current.color, width: '100%'}}>
              Entendido
            </button>
          )}
        </div>}
      </div>
    </div>
  );
}

// 🎨 ESTILOS ACTUALIZADOS
const styles = {
  loading: {
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(180deg, rgba(255,77,77,1), rgba(255,210,74,1), rgba(30,144,255,1))",
    color: "#fff",
  },
  loadingLogo: { width: 120, animation: "pop 1s ease infinite alternate" },
  authContainer: {
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(180deg, rgba(255,77,77,1), rgba(255,210,74,1), rgba(30,144,255,1))",
    color: "#fff",
  },
  authLogo: { width: 100, marginBottom: 20 },
  form: {
    background: "rgba(255,255,255,0.15)",
    padding: 24,
    borderRadius: 16,
    width: 300,
    display: "flex",
    flexDirection: "column",
    gap: 10,
  },
  input: { padding: 10, borderRadius: 8, border: "none", fontFamily: "inherit" },
  button: {
    background: "#1e90ff",
    color: "#fff",
    border: "none",
    padding: 10,
    borderRadius: 8,
    cursor: "pointer",
    fontWeight: "bold",
  },
  header: {
    background: "linear-gradient(90deg, rgba(255,77,77,1), rgba(255,210,74,1), rgba(30,144,255,1))",
    color: "#fff",
    padding: 16,
    fontWeight: "bold",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  menuBtn: {
    background: "none",
    border: "none",
    color: "white",
    fontSize: "1.8rem",
    cursor: "pointer",
  },
  profileBtn: {
    background: "none",
    border: "none",
    cursor: "pointer",
    borderRadius: "50%",
    padding: 6,
  },
  logoutBtn: {
    background: "none",
    border: "none",
    cursor: "pointer",
    marginLeft: 8,
    padding: 6,
  },
  logoutBtnFull: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    background: "#ff4d4d",
    border: "none",
    color: "#fff",
    borderRadius: 8,
    padding: "10px",
    cursor: "pointer",
  },
  hero: {
    textAlign: "center",
    padding: 30,
    background: "linear-gradient(180deg, rgba(255,77,77,0.15), rgba(255,210,74,0.15))",
  },
  benefits: {
    padding: "50px 20px",
    background: "#f5f5f5",
    textAlign: "center",
  },
  benefitsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
    gap: 20,
    marginTop: 30,
    maxWidth: "1200px",
    margin: "30px auto 0",
  },
  benefitCard: {
    background: "#fff",
    padding: 30,
    borderRadius: 12,
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
  },
  benefitIcon: {
    width: "50px",
    height: "50px",
    marginBottom: "10px",
  },
  menu: { padding: 30, textAlign: "center" },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
    gap: 20,
    marginTop: 24,
  },
  card: {
    background: "#fff",
    padding: 16,
    borderRadius: 12,
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
  },
  filterContainer: {
    display: "flex",
    justifyContent: "center",
    gap: 10,
    marginBottom: 24,
    flexWrap: "wrap",
  },
  filterButton: {
    padding: "8px 16px",
    borderRadius: 20,
    border: "1px solid #1e90ff",
    background: "transparent",
    color: "#1e90ff",
    cursor: "pointer",
    fontWeight: "bold",
  },
  filterButtonActive: {
    padding: "8px 16px",
    borderRadius: 20,
    border: "1px solid rgba(30, 101, 255, 1)",
    background: "#1e47ffff",
    color: "#fff",
    cursor: "pointer",
    fontWeight: "bold",
  },
  orderCard: {
    background: '#fafafa',
    border: '1px solid #eee',
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
    lineHeight: 1.6
  },
  deleteOrderBtn: {
    background: 'none',
    border: 'none',
    cursor: 'pointer',
    padding: 5
  },
  image: {
    width: "100%",
    height: 180,
    objectFit: "cover",
    borderRadius: 10,
    marginBottom: 10,
  },
  addBtn: {
    background: "#ff4d4d",
    color: "#fff",
    border: "none",
    padding: "6px 12px",
    borderRadius: 8,
    cursor: "pointer",
  },
  cardFooter: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 },
  promos: {
    padding: "40px 20px",
    background: "linear-gradient(180deg, rgba(255,210,74,0.05), rgba(30,144,255,0.05))",
    textAlign: "center",
    overflowX: "hidden",
  },
  gallery: {
    display: "flex",
    width: `calc(270px * 10)`, // 250px de tarjeta + 20px de gap
    gap: "20px",
    animation: "scroll-horizontal 10s linear infinite",
  },
  promoCard: {
    position: "relative",
    background: "#fff",
    borderRadius: "16px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
    transition: "transform 0.3s ease",
    "&:hover": {
      transform: "scale(1.05)",
    },
    display: 'flex',
    flexDirection: 'column',
    width: 250,
    height: 250,
  },
  promoImg: {
    width: "100%",
    height: "150px",
    objectFit: "cover", // Asegura que la imagen cubra el espacio
    borderTopLeftRadius: "16px",
    borderTopRightRadius: "16px",
  },
  testimonios: {
    padding: "50px 20px",
    background: "linear-gradient(180deg, rgba(255,77,77,0.05), rgba(30,144,255,0.05))",
    textAlign: "center",
  },
  testimoniosGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
    gap: 20,
    marginTop: 30,
    maxWidth: "1200px",
    margin: "30px auto 0",
  },
  promoCardContent: {
    padding: '10px',
    flexGrow: 1,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  contacto: {
    padding: "50px 20px",
    background: "linear-gradient(90deg, rgba(255,77,77,0.1), rgba(30,144,255,0.1))",
    textAlign: "center",
  },
  contactoInfo: {
    marginTop: 30,
    fontSize: "1.1rem",
    lineHeight: 2,
  },
  contactIcon: {
    width: "20px",
    height: "20px",
    verticalAlign: "middle",
    marginRight: "10px",
  },
  cartButton: {
    position: "fixed",
    bottom: 40,
    right: 40,
    background: "#1e90ff",
    color: "#fff",
    borderRadius: "50%",
    width: 60,
    height: 60,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "1.5rem",
    cursor: "pointer",
    boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
  },
  cartCount: {
    position: "absolute",
    top: -5,
    right: -5,
    background: "#ff4d4d",
    color: "#fff",
    borderRadius: "50%",
    width: 24,
    height: 24,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "0.8rem",
    fontWeight: "bold",
  },
  cartPanel: {
    position: "fixed",
    bottom: 90,
    right: 20,
    background: "#fff",
    borderRadius: 12,
    padding: 20,
    width: 300,
    boxShadow: "0 4px 12px rgba(0,0,0,0.3)",
    color: "#000",
    maxHeight: "400px",
    overflowY: "auto",
  },
  cartItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
    fontSize: '0.95rem',
  },
  quantityControl: {
    display: 'flex',
    alignItems: 'center',
  },
  quantityBtn: {
    background: '#eee',
    border: 'none',
    borderRadius: '50%',
    width: 24,
    height: 24,
    cursor: 'pointer',
    fontWeight: 'bold',
  },
  removeBtn: { background: "none", border: "none", color: "red", cursor: "pointer", fontWeight: "bold" },
  clearBtn: {
    background: "#ff4d4d",
    border: "none",
    color: "#fff",
    padding: 8,
    width: "100%",
    borderRadius: 8,
    cursor: "pointer",
  },
  confirmBtn: {
    background: "#1e90ff",
    border: "none",
    color: "#fff",
    padding: 8,
    width: "100%",
    borderRadius: 8,
    cursor: "pointer",
  },
  modalOverlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: "rgba(0,0,0,0.6)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 1000,
  },
  modal: {
    background: "#fff",
    borderRadius: 12,
    padding: 20,
    width: 320,
    boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
    textAlign: "center",
  },
  sideMenuOverlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: "rgba(0,0,0,0.5)",
    zIndex: 1000,
  },
  sideMenu: {
    position: "fixed",
    top: 0,
    left: 0,
    bottom: 0,
    width: "280px",
    background: "#fff",
    padding: 20,
    boxShadow: "2px 0 10px rgba(0,0,0,0.2)",
    display: "flex",
    flexDirection: "column",
  },
  menuSection: { flexGrow: 1, borderTop: "1px solid #eee", paddingTop: 10, marginTop: 10 },
  footer: {
    textAlign: "center",
    padding: "15px 30px",
    background: "linear-gradient(90deg, rgba(255,77,77,1), rgba(255,210,74,1), rgba(30,144,255,1))",
    color: "#fff",
    fontWeight: "500",
    fontSize: "0.9rem",
    marginTop: 30,
    justifyContent: "space-between",
    alignItems: "center",
  },
  socialLink: {
    marginLeft: "15px",
  },
  socialIcon: {
    width: "24px",
    height: "24px",
  },
};