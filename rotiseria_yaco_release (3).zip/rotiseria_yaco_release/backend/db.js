// db.js
const { MongoClient } = require('mongodb');

const uri = process.env.MONGODB_URI; // Usaremos una variable de entorno para la URI
const client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

let dbInstance = null;

async function connectDB() {
  if (dbInstance) {
    return dbInstance;
  }
  try {
    await client.connect();
    console.log("Conectado a MongoDB");
    dbInstance = client.db("rotiseria_yaco"); // Reemplaza con el nombre de tu base de datos
    return dbInstance;
  } catch (e) {
    console.error("Error al conectar a MongoDB", e);
    process.exit(1);
  }
}

module.exports = connectDB;
