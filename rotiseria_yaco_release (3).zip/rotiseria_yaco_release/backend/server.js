const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const express = require('express');
const cors = require('cors');
const { ObjectId } = require('mongodb');
const connectDB = require('./db');

const app = express();
const port = process.env.PORT || 5000;

// Middlewares
app.use(cors()); // Permite peticiones desde tu app de React
app.use(express.json()); // Permite al servidor entender JSON

let db; // Variable para almacenar la instancia de la base de datos

// Conectar a la base de datos y luego iniciar el servidor
connectDB().then(database => {
  db = database;
  
  // --- Rutas de la API ---

  // Obtener todos los items del menú
  app.get('/api/menu', async (req, res) => {
    try {
      const menuItems = await db.collection('menuItems').find({}).toArray(); // Cambiado a 'menuItems'
      res.json(menuItems);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener el menú' });
    }
  });

  // Registro de usuario
  app.post('/api/register', async (req, res) => {
    try {
      const { nombre, apellido, email, password } = req.body;
      const existingUser = await db.collection('users').findOne({ email });

      if (existingUser) {
        return res.status(400).json({ message: 'Este correo ya está registrado.' });
      }

      const result = await db.collection('users').insertOne({ nombre, apellido, email, password, createdAt: new Date() }); // Añadido createdAt
      const newUser = await db.collection('users').findOne({ _id: result.insertedId });
      res.status(201).json(newUser);
    } catch (error) {
      res.status(500).json({ message: 'Error en el registro' });
    }
  });

  // Login de usuario
  app.post('/api/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await db.collection('users').findOne({ email, password });

      if (user) {
        res.json(user);
      } else {
        res.status(401).json({ message: 'Usuario o contraseña incorrectos' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Error al iniciar sesión' });
    }
  });

  // Crear un nuevo pedido
  app.post('/api/orders', async (req, res) => {
    try {
      const order = { ...req.body, createdAt: new Date() }; // Añadido createdAt
      const result = await db.collection('orders').insertOne(order);
      res.status(201).json({ ...order, _id: result.insertedId });
    } catch (error) {
      res.status(500).json({ message: 'Error al crear el pedido' });
    }
  });

  // Obtener pedidos de un usuario
  app.get('/api/orders/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      // Asumiendo que guardas el email del usuario en el pedido
      const orders = await db.collection('orders').find({ 'cliente.email': userId }).toArray();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: 'Error al obtener los pedidos' });
    }
  });


  app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
  });

}).catch(console.error);


// --- Datos iniciales (puedes ejecutar esto una vez para poblar tu DB) ---
async function seedDatabase() {
  try {
    const database = await connectDB();
    const menuCollection = database.collection('menuItems'); // Cambiado a 'menuItems'
    const count = await menuCollection.countDocuments();

    if (count === 0) {
      console.log('Poblando la base de datos con items del menú...');
      const menuItems = [
        {
          name: "Milanesa de choclo con papas",
          desc: "Milanesa de choclo con papas de carne ",
          price: 20000,
          img: "/imagenes/milanesa choclo con papas.jpg",
          category: "Milanesas",
        },
        {
          name: "Empanada de Carne dulce",
          desc: "Empanada de Carne dulce",
          price: 1500,
          img: "/imagenes/emp-de-carnedulce.jpeg",
          category: "Empanadas",
        },
        {
          name: "Ensalada fresca",
          desc: "Mix de hojas verdes y vegetales",
          price: 3000,
          img: "/imagenes/ensalada.webp",
          category: "Guarnicion",
        },
        {
          name: "Milanesa de choclo con papas",
          desc: "Milanesa de choclo con papas de pollo",
          price: 19000,
          img: "/imagenes/milanesa choclo con papas.jpg",
          category: "Milanesas",
        },
        {
          name: "Empanada",
          desc: "Carne Salada",
          price: 800,
          img: "/imagenes/emp-de-carnesalada.jpeg",
          category: "Empanadas",
        },
        {
          name: "Milanesa con papas",
          desc: "Milanesa de napolitana de carne",
          price: 20000,
          img: "/imagenes/milanesa-de-napolitana.webp",
          category: "Milanesas",
        },
        {
          name: "Empanada",
          desc: "Arabe",
          price: 1500,
          img: "/imagenes/emp-de-arabe.jpeg",
          category: "Empanadas",
        },
        {
          name: "Pizza ",
          desc: "Npolitana ",
          price: 14000,
          img: "/imagenes/pizza-de-napo.webp",
          category: "Pizzas",
        },
        {
          name: "Pizza",
          desc: "Pizza con muzzarella",
          price: 11000,
          img: "/imagenes/pizza-de-muzza.webp",
          category: "Pizzas",
        },
        {
          name: "Pizzanesa Napolitana",
          desc: "Pizzanesa de Napolitana para 4 personas",
          price: 2000,
          img: "/imagenes/pizzanesa.webp",
          category: "Pizzanesas",
        },
        {
          name: "Gaseosa Coca-Cola 1.5L",
          desc: "Refresco de cola",
          price: 5000,
          img: "/imagenes/coca-cola.webp",
          category: "Bebidas",
        },
        {
          name: "Agua saborizada 1,500ml",
          desc: "Agua mineral sin gas",
          price: 4000,
          img: "/imagenes/fresh.webp",
          category: "Bebidas",
        },
      ];
      await menuCollection.insertMany(menuItems);
      console.log('Base de datos poblada con el menú inicial.');
    }
  } catch (error) {
    console.error('Error al poblar la base de datos:', error);
  }
}

seedDatabase(); // Descomenta para poblar la base de datos la primera vez